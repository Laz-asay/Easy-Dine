<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Successful</title>
    <link rel="stylesheet" href="confirmation.css">
</head>
<body>
    <div class="confirmation-container">
        <h1>Thank You!</h1>
        <p>Your order has been placed successfully.</p>
        <a href="mainpage.php" class="back-to-menu">Back to Menu</a>
    </div>
</body>
</html>
